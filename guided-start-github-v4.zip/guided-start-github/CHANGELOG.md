# Changelog

## v4 — 2026-09-27

Guided Start v4 is a behavioral rebuild rather than a small revision of v3.

### Changed

- Reframed Tier 1 choices as **starting postures**, not conversational modes.
- Added the principle **Tier 2 gives bearings, not requirements**.
- Added a Do bearings rung: Write / Edit, Make sense of some information, Plan / Organize, Research, Technical work, Prepare.
- Refined Solve around Roadblock, Processing, Deciding, and Talk it out.
- Added Explore thought-beginnings: I have a question…, I was wondering…, Dig deeper on…, Is it true that…, I don't know — show me.
- Rebuilt Create around vision, progressive reveal, preservation of authorship, and increasing fidelity as the idea becomes clearer.
- Rebuilt Surprise Me to expand the user's mental model of AI through demonstration rather than trivia.
- Strengthened progressive context and adaptive-assistance behavior.
- Strengthened creation requirements so creative work materializes rather than remaining prose-only.
- Strengthened preservation behavior so worthwhile conversations receive a lightweight rename/pin/save nudge.
- Improved Markdown structure and runtime readability of `SKILL.md`.

### Design direction

v4 treats Guided Start as a small amount of temporary scaffolding that should disappear as the user gains footing and the conversation develops its own momentum.

## v3

Public pilot of the original Guided Start interaction model.
