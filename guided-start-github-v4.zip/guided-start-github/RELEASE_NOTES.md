# Guided Start v4

Guided Start v4 is a substantial rebuild based on real-world testing of the public pilot.

The central idea remains the same: help people cross the gap between having something in their head and knowing how to begin working on it with AI.

What changed is the interaction model.

## Highlights

- **Starting postures, not lanes.** Do, Solve, Explore, Create, and Surprise Me establish an initial posture and then fade as context grows.
- **Bearings, not requirements.** The first two rungs exist to help the user recognize where they are, not to collect a brief.
- **Do now has practical bearings.** Write / Edit, Make sense of some information, Plan / Organize, Research, Technical work, Prepare.
- **Explore starts thoughts instead of categorizing curiosity.** The user can begin with “I have a question…”, “I was wondering…”, “Dig deeper on…”, “Is it true that…”, or “I don't know — show me”.
- **Create now centers the user's vision.** The model should progressively reveal the idea, materialize early, preserve authorship, and avoid polishing what has not yet been discovered.
- **Surprise Me expands the map.** The goal is to demonstrate what AI interaction can become, preferably breaking the text-in/text-out expectation when useful.
- **Adaptive assistance is continuous.** The model should carry more cognitive load when momentum is low and become less visible as the user gets moving.
- **Worthwhile work should be preserved.** The skill includes an explicit lightweight nudge to rename, pin, save, or otherwise preserve valuable conversations where supported.

## Testing

The most useful tests are ordinary ones. Open a new conversation and type:

```text
start
```

Then use whatever choice feels closest. Pay attention to whether Guided Start creates momentum without feeling like a wizard, intake form, or prompt-building exercise.
