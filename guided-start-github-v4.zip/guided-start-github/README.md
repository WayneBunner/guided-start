# Guided Start

**A guided AI experience for when you don't know where to start.**

Guided Start is a platform-independent interaction model for the blank-box problem: AI can do a lot, but that is not very helpful when you do not yet have a prompt, a clear question, or even know what is worth asking.

It helps turn “I don't know where to start” into useful momentum without turning the conversation into an intake form or a prompting lesson. The packaged implementation in this repository is a ChatGPT Skill; the underlying Guided Start behavior is intended to travel across AI environments.

## Try it

1. Open the `release` folder and download `skill.zip`.
2. Open a new ChatGPT conversation.
3. Attach `skill.zip` and say `Install this Skill.`
4. Once installed, open a new chat and type:

```text
start
```

That is intentionally all you need to know.

## The opening

```text
Guided Start
Let's get started.

Start with the direction that feels closest:

1. Do — get something done.
2. Solve — work through something.
3. Explore — dig into something you're curious about.
4. Create — make or improve something.
5. Surprise me — show me something I might not know ChatGPT can do.

What number is closest?
```

The choices are starting postures, not permanent modes. Guided Start should become less visible as useful context and momentum build.

## Design principles

Guided Start is built around a few practical ideas:

- **Prime the pump.** The first one or two movements should be unusually easy.
- **Bearings, not requirements.** Early choices should help users recognize where they are, not complete an intake form.
- **Carry cognitive load.** The AI should contribute useful material rather than repeatedly asking the user to formulate everything.
- **Progressive context.** Each turn should provide value now while improving the shared context for what follows.
- **Adaptive assistance.** Increase assistance when momentum is low; become less visible when the user is moving.
- **Create the thing.** In creative work, materialize early and build cumulatively rather than talking indefinitely about what could be made.
- **Preserve authorship.** Creative assistance should reveal the user's vision rather than replace it.
- **Preserve worthwhile work.** Once the conversation becomes something the user would reasonably want to find again, surface a lightweight reminder to rename, pin, save, or otherwise preserve it when the platform supports that.

## The five starting postures

### Do

Join the work. If more footing is needed, provide quick bearings through recognizable shapes of work:

1. Write / Edit
2. Make sense of some information
3. Plan / Organize
4. Research
5. Technical work
6. Prepare

### Solve

Establish the right footing for the problem. Useful bearings include Roadblock, Processing, Deciding, and Talk it out. The posture should adapt to the shape of the problem rather than forcing a diagnostic workflow.

### Explore

Feed curiosity and follow what catches. When a second rung helps, use thought beginnings rather than subject categories:

1. I have a question…
2. I was wondering…
3. Dig deeper on…
4. Is it true that…
5. I don't know — show me

### Create

Ask:

> **What idea do you want to see come alive?**
>
> *It doesn't have to be fully formed.*

Treat creation as progressive reveal: **vision → reveal → reaction → clearer vision → deeper reveal**. Materialize early, preserve authorship, and increase fidelity as the vision becomes clearer. Don't polish what has not been discovered yet.

### Surprise me

Expand the user's mental model of what working with AI can be. Demonstrate rather than explain. Prefer visual, interactive, tangible, or otherwise experiential surprises that break the text-in/text-out expectation when appropriate. Trivia and generic fun facts do not satisfy this posture.

## Why this exists

A common AI adoption problem is simple:

> People are told AI can do almost anything, then they are handed an empty text box.

Most prompt guidance assumes the user already knows what they want. Guided Start begins one step earlier: at the moment before the prompt exists.

The goal is not to manufacture a better prompt. The goal is to start useful work.

## Status

**v4 — active pilot**

v4 rebuilds the interaction model around starting postures, low-friction bearings, progressive context, adaptive assistance, materialization, preservation, and real-world testing.

Behavioral feedback is especially useful:

- Where did the conversation stall?
- Where did the AI make you do unnecessary work?
- Where did a choice give you useful bearings?
- Where did the AI take over too much?
- Where did Create talk about the thing instead of making it?
- Where did Surprise Me fail to expand your sense of what AI can do?
- Where should the conversation have been preserved or renamed?
- Where did it unexpectedly create momentum?

Please remove private, confidential, or proprietary information before sharing transcripts.

## Repository layout

```text
guided-start/
├── README.md
├── LICENSE
├── CHANGELOG.md
├── RELEASE_NOTES.md
├── guided-start/
│   ├── SKILL.md
│   ├── agents/
│   │   └── openai.yaml
│   └── assets/
│       └── icon.svg
└── release/
    └── skill.zip
```

The `guided-start/` directory is the readable source. `release/skill.zip` is the installable ChatGPT package.

## Contributing

Issues are the preferred feedback mechanism during the pilot. When reporting behavior, include:

1. What you typed or were trying to do.
2. What Guided Start did.
3. Where the interaction gained or lost momentum.
4. What you expected instead, if you had a clear expectation.

## License

MIT. See `LICENSE`.
